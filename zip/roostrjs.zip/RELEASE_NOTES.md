
Version 0.2.2 ()
------------------------------
 * Documentation

Version 0.2.1 (July 12th 2017)
------------------------------
 * New PerspectiveCamera and OrthographicCamera classes to chose different types of projections.
 * New setDepthTest(), setBlendFunction() and setBlendEquation() in rendererTarget class to allow different types of blendings

Version 0.2.0 (July 5th 2017)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Examples

Version 0.1.0 (July 1st 2014)
-----------------------------
 * initial version
