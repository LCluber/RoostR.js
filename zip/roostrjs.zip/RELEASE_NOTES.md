
Version 0.2.1 ()
------------------------------
 * Documentation

Version 0.2.0 (July 5th 2017)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Examples

Version 0.1.0 (July 1st 2014)
-----------------------------
 * initial version
