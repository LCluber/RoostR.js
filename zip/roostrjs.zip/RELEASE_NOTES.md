Version 0.3.1 (soon)
------------------------------
 * Documentation

Version 0.4.0 (September 16th 2017)
------------------------------
 * Added material class 

Version 0.3.0 (September 10th 2017)
------------------------------
 * Added activateBlendMode() and deactivateBlendMode() to the Mesh class 
 * Blend modes are now at material level instead of scene level
 * Added customMesh geometry to create custom shapes easily
 * Added lights classes for a better lights management system

Version 0.2.7 (August 27th 2017)
------------------------------
 * Added multi materials capability to the mesh class

Version 0.2.6 (August 26th 2017)
------------------------------
 * Added a scene graph and the ability to add children to a mesh with mesh.addChild(mesh) method.
 * Added Gun0 geometry.

Version 0.2.5 (August 15th 2017)
------------------------------
 * Ability to send custom uniforms to the shaders using addUniform() and setUniform() methods in the mesh class.

Version 0.2.4 (August 10th 2017)
------------------------------
 * Added Hemisphere geometry.

Version 0.2.3 (July 30th 2017)
------------------------------
 * Added Line geometry to draw lines.

Version 0.2.2 (July 23th 2017)
------------------------------
 * Added Quad geometry to draw quads.
 * Fixed a bug with texture coordinates.
 * Added enableDepthTest(), disableDepthTest(), enableBlendMode() and disableBlendMode() methods in rendererTarget class to facilitate blending modifications along the rendering loop.

Version 0.2.1 (July 14th 2017)
------------------------------
 * New PerspectiveCamera and OrthographicCamera classes to chose different types of projections.
 * New setDepthTest(), setBlendFunction() and setBlendEquation() methods in rendererTarget class to allow different types of blendings.

Version 0.2.0 (July 5th 2017)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Examples

Version 0.1.0 (July 1st 2014)
-----------------------------
 * initial version
