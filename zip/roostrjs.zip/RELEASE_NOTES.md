
Version 0.2.3 (soon)
------------------------------
 * Documentation

 Version 0.2.2 (July 23th 2017)
 ------------------------------
  * Added Quad geometry to draw quads.
  * Fixed a bug with texture coordinates.
  * Added enableDepthTest(), disableDepthTest(), enableBlendMode() and disableBlendMode() methods in rendererTarget class to facilitate blending modifications along the rendering loop.

Version 0.2.1 (July 14th 2017)
------------------------------
 * New PerspectiveCamera and OrthographicCamera classes to chose different types of projections.
 * New setDepthTest(), setBlendFunction() and setBlendEquation() methods in rendererTarget class to allow different types of blendings.

Version 0.2.0 (July 5th 2017)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Examples

Version 0.1.0 (July 1st 2014)
-----------------------------
 * initial version
